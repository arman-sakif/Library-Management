/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarymanagementsystem;

/**
 *
 * @author Akech
 */
public class BookVal {
    private int bookID;
    private String bookName, author, genre, shelf;

    public BookVal() {
    }

    public BookVal(int bookID, String bookName, String author, String genre, String shelf) {
        this.bookID = bookID;
        this.bookName = bookName;
        this.author = author;
        this.genre = genre;
        this.shelf = shelf;
    }

    public int getBookID() {
        return bookID;
    }

    public String getBookName() {
        return bookName;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    public String getShelf() {
        return shelf;
    }
    
    
}
